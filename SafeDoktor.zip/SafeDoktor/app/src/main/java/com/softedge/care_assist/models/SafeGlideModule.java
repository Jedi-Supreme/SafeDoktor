package com.softedge.care_assist.models;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public class SafeGlideModule extends AppGlideModule {
}
