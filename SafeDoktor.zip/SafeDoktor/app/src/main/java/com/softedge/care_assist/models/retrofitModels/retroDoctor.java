package com.softedge.care_assist.models.retrofitModels;

import com.google.gson.annotations.SerializedName;

public class retroDoctor {

    @SerializedName("firstName")
    String firstName;

    @SerializedName("lastName")
    String lastName;

    @SerializedName("specialty")
    String specialty;


}
